
# Xman Language (Lua Version)

This is a basic interpreter for a custom language called Xman, written in Lua.

## Features

- `say text` - Prints the text
- `add a b` - Adds two numbers
- `set name value` - Stores a variable
- `get name` - Retrieves a variable
- `wait n` - Waits n seconds (simulated)
- `exit` - Exits the interpreter

## How to Run

You need [Lua](https://www.lua.org/) installed. Then run:

```bash
lua xman.lua
```

## Example Commands

```xman
say Hello from Xman!
set name John
get name
add 3 4
wait 1
exit
```
