-- xman.lua
local modules = {
    logic = require("modules.logic"),
    emotion = require("modules.emotion"),
    memory = require("modules.memory"),
    automation = require("modules.automation"),
    simulation = require("modules.simulation")
}

local function runXmanLine(line)
    local command = string.lower(string.match(line, "^%s*(%w+)"))
    if modules[command] then
        modules[command].run(line)
    else
        print("[Xman] Unknown command:", command)
    end
end

-- Simple REPL
print("[Xman] Universal Lua-based scripting language.")
while true do
    io.write("> ")
    local line = io.read()
    if line == "exit" then break end
    runXmanLine(line)
end
