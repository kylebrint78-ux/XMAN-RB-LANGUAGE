-- modules/simulation.lua
local simulation = {}

function simulation.run(line)
    if line:match("wait") then
        local t = tonumber(line:match("wait (%d+)"))
        print("[Simulation] Waiting for", t, "seconds...")
        os.execute("sleep " .. tonumber(t))
    else
        print("[Simulation] Invalid simulation command")
    end
end

return simulation
