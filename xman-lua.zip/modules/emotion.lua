-- modules/emotion.lua
local emotion = {}

local state = "neutral"

function emotion.run(line)
    if line:match("happy") then
        state = "happy"
    elseif line:match("sad") then
        state = "sad"
    end
    print("[Emotion] Current state:", state)
end

return emotion
