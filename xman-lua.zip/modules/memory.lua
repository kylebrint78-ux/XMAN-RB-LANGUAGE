-- modules/memory.lua
local memory = {}
local store = {}

function memory.run(line)
    local cmd, k, v = line:match("(%w+)%s+(%w+)%s*(.*)")
    if cmd == "set" then
        store[k] = v
        print("[Memory] Set", k, "to", v)
    elseif cmd == "get" then
        print("[Memory] Get", k, "=", store[k])
    else
        print("[Memory] Invalid memory command")
    end
end

return memory
