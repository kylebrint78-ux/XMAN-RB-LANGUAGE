-- modules/logic.lua
local logic = {}

function logic.run(line)
    local _, _, a, op, b = string.find(line, "(%d+)%s*(==|~=|>|<|>=|<=)%s*(%d+)")
    if a and op and b then
        a, b = tonumber(a), tonumber(b)
        local result = load("return " .. a .. op .. b)()
        print("[Logic]", result)
    else
        print("[Logic] Invalid logic command")
    end
end

return logic
