-- modules/automation.lua
local automation = {}

function automation.run(line)
    if line:match("repeat") then
        local _, _, times, cmd = line:find("repeat (%d+)%s+(.+)")
        times = tonumber(times)
        for i = 1, times do
            print("[Automation]", cmd)
        end
    else
        print("[Automation] Invalid automation command")
    end
end

return automation
